export default /* glsl */`
#ifdef CLEARCOAT

	vec3 clearcoatNormal = geometryNormal;

#endif
`;
